#include "includes.hpp"

int main() {
	Interface interface;
	interface.start();
	interface.run();
	return 0;
}

#ifndef RELEASED_TRAIN_HPP
#define RELEASED_TRAIN_HPP

#include "const_variable.hpp"

class ReleasedTrain {
public:
	int ticket[DATE_MAX][STATION_LEN];
};

#endif // RELEASED_TRAIN_HPP
